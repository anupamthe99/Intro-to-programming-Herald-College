new_list=[1,2,3,4,5,6]
new_integer=7
new_list.append(new_integer)
print(new_list)
