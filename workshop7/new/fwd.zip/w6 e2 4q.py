my_set={1,2,3,4,5,6}
my_set.add(7)
print(my_set)
