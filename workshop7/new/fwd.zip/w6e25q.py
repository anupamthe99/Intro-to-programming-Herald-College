students_name={"ram":19,"shyam":20,"hari":34,"nabin":89}
print("age of"student_name,"shyam")
