dictionary_student={"Avimanyu":20,"Asmita":19,"john":21}
student_name="Asmita"
print(dictionary_student[student_name])
