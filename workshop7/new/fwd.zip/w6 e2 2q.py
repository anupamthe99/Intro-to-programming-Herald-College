list=[["mango","litchi","apple"],["book","laptop","pen"],["hey","baby","hello"]]
print(list[1][0])
